from brain_games.games import even


__all__ = ["even"]